# Instanciamos detector de descriptores
import cv2
import numpy as np


def detectarFormas(image, minThr, maxThr):
    img = image.copy()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Comprobamos en primer lugar si estamos detectando círculos, la funcion HoughCircles tendra como parametros las
    # variables minThr y maxThr, que seran los valores de los umbrales de la imagen binaria, si bajan dichos
    # valores de 20 el programa sufre un fallo de memoria, por lo que se ha decidido ponerles un minimo.

    minThr2 = minThr
    maxThr2 = maxThr
    if minThr2 < 20:
        minThr2 = 20
    if maxThr2 < 40:
        maxThr2 = 40
    rows = gray.shape[0]
    circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, rows / 8,
                               param1=minThr2, param2=maxThr2,
                               minRadius=1, maxRadius=300)
    if circles is not None:
        circles = np.uint16(np.around(circles))
        for i in circles[0, :]:
            # Calculamos el centro de la imagen y mostramos por pantalla el contorno de color rosa
            center = (i[0], i[1])
            radius = i[2]
            cv2.circle(image, center, radius, (255, 0, 255), 3)

    # Pasamos a comprobar el resto de formas
    canny = cv2.Canny(gray, minThr, maxThr)
    canny = cv2.dilate(canny, None, iterations=1)
    canny = cv2.erode(canny, None, iterations=1)
    cnts, _ = cv2.findContours(canny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # OpenCV 4
    # cv2.drawContours(image, cnts, -1, (0,255,0), 2)
    for c in cnts:
        epsilon = 0.01 * cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, epsilon, True)
        x, y, w, h = cv2.boundingRect(approx)
        # Pintamos los triangulos de verde
        if len(approx) == 3:
            cv2.drawContours(image, [approx], 0, (0, 255, 0), 2)
        # Identificamos cuadrilateros
        elif len(approx) == 4:
            v1 = [approx[1, 0, 0] - approx[0, 0, 0], approx[1, 0, 1] - approx[0, 0, 1]]
            v2 = [approx[2, 0, 0] - approx[1, 0, 0], approx[2, 0, 1] - approx[1, 0, 1]]
            v3 = [approx[3, 0, 0] - approx[2, 0, 0], approx[3, 0, 1] - approx[2, 0, 1]]
            v4 = [approx[0, 0, 0] - approx[3, 0, 0], approx[0, 0, 1] - approx[3, 0, 1]]
            prod_escalar = v1[0] * v2[0] + v1[1] * v2[1]
            prod_escalar3 = v3[0] * v4[0] + v3[1] * v4[1]
            modulo_v1 = np.sqrt(v1[0] ** 2 + v1[1] ** 2)
            modulo_v2 = np.sqrt(v2[0] ** 2 + v2[1] ** 2)
            modulo_v3 = np.sqrt(v3[0] ** 2 + v3[1] ** 2)
            modulo_v4 = np.sqrt(v4[0] ** 2 + v4[1] ** 2)
            coseno = prod_escalar / (modulo_v1 * modulo_v2)
            coseno3 = prod_escalar3 / (modulo_v3 * modulo_v4)
            angulo = np.arccos(coseno)
            angulo3 = np.arccos(coseno3)
            angulo = np.rad2deg(angulo)
            angulo3 = np.rad2deg(angulo3)
            if 85 < angulo < 95:
                aspectRatio = float(w) / h
                if aspectRatio >= 0.95 and aspectRatio <= 1.05:
                    # Pintamos los  cuadrados de naranja
                    cv2.drawContours(image, [approx], 0, (0, 125, 255), 2)
                else:
                    # Pintamos los rectangulos de rojo
                    cv2.drawContours(image, [approx], 0, (0, 0, 255), 2)
            else:
                if (angulo3 - 10 < angulo < angulo3 + 10):
                    # pintamos los rombos de amarillo
                    cv2.drawContours(image, [approx], 0, (0, 255, 255), 2)
                else:
                    # Pintamos los trapecios de morado
                    cv2.drawContours(image, [approx], 0, (255, 23, 139), 2)
        # Pintamos los pentagonos de azul oscuro
        elif len(approx) == 5:
            cv2.drawContours(image, [approx], 0, (255, 0, 0), 2)
        # Pintamos los hexagonos de color azul claro
        elif len(approx) == 6:
            cv2.drawContours(image, [approx], 0, (250, 250, 0), 2)
    return image


if __name__ == '__main__':

    cap = cv2.VideoCapture(0)
    minThr = 50
    maxThr = 150
    # Mostramos además un display por pantalla con los valores de minThr y maxThr
    ret, imagen = cap.read()
    cv2.imshow('Imagen', imagen)
    cv2.createTrackbar('minThr', 'Imagen', minThr, 255, lambda x: None)
    cv2.createTrackbar('maxThr', 'Imagen', maxThr, 255, lambda x: None)
    while cap.isOpened():
        ret, imagen = cap.read()
        imagenAlterada = detectarFormas(imagen, minThr, maxThr)
        # Mostramos la imagen por pantalla
        cv2.imshow('Imagen', imagenAlterada)
        # Actualizamos los valores de minThr y maxThr
        minThr = cv2.getTrackbarPos('minThr', 'Imagen')
        maxThr = cv2.getTrackbarPos('maxThr', 'Imagen')

        # Esperamos a pulsar una tecla
        tecla = cv2.waitKey(5) & 0xFF
        # Si la tecla es ESC salimos del bucle
        if tecla == 27:
            break
    cap.release()
    cv2.destroyAllWindows()
