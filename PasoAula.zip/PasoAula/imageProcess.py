import cv2
import numpy
import numpy as np


def getCentroideY(img, primeraImagen, tamImagenX, mostrarVentanas=False):

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Restar imagen actual con la primera imagen
    resta = cv2.absdiff(primeraImagen, gray)

    # Eliminar el ruido
    ret, thresh = cv2.threshold(resta, 60, 255, cv2.THRESH_BINARY)

    # Calcular centroides
    contours, h = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    puntosX = []
    puntosY = []
    for c in contours:
        # Solo hace falta guardar las coordenadas y de los centroides
        puntosX.append(c[0][0][0])
        puntosY.append(c[0][0][1])

    # Si no se encuentra ningun centroide, se retornara -1
    cy = -1

    if (numpy.size(puntosY) and numpy.size(puntosX)) != 0:
        cx = np.mean(puntosX)
        cy = np.mean(puntosY)
        # Dibujar circulo en el centroide
        cv2.circle(img, (int(cx), int(cy)), 5, (0, 255, 255), -1)
        cv2.line(img, (0, int(cy)), (tamImagenX, int(cy)), (0, 255, 255), 2)

    if mostrarVentanas:
        cv2.imshow('Imagen original en gris', primeraImagen)
        cv2.imshow('Grayscale', gray)
        cv2.imshow('Resta', resta)
        cv2.imshow('Threshold', thresh)

    return cy
