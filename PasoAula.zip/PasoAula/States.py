from enum import Enum


class States(Enum):
    """Clase Enum para los estados del paso de aula."""
    FUERA = "Fuera"
    ENTRANDO = "Entrando"
    SALIENDO = "Saliendo"
    DENTRO = "Dentro"
