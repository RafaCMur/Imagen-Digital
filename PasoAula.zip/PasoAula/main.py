import sys

import cv2
from PyQt5 import uic, QtGui, QtCore
from PyQt5.QtWidgets import QApplication

import States as st
import imageProcess


class Window:
    cap = cv2.VideoCapture('video.wmv')
    ret, originalFrame = cap.read()
    speed_default = 60
    speed_actual = 60
    mostrarVentanas = False

    def __init__(self):
        # Al principio se supone que el hombre está dentro de la habitación y el contador es 1
        self.state = st.States.DENTRO
        self.contador = 1

        # Tamaño de la ventana en píxeles
        self.tamX = 500
        self.tamY = 350

        self.primeraImagen = None
        self.primeraIsTaken = False

        self.MainWindow = uic.loadUi('mainwindow.ui')
        self.MainWindow.setWindowTitle("Entrega 3 - Looking for something")

        self.MainWindow.sliderBarrera1.setRange(0, self.tamY)
        self.MainWindow.spinBarrera1.setRange(0, self.tamY)

        self.MainWindow.sliderBarrera2.setRange(0, self.tamY)
        self.MainWindow.spinBarrera2.setRange(0, self.tamY)

        self.MainWindow.spinBarrera1.setValue(100)
        self.MainWindow.spinBarrera2.setValue(100)

        self.MainWindow.sliderBarrera1.valueChanged.connect(self.change_barrier)
        self.MainWindow.sliderBarrera2.valueChanged.connect(self.change_barrier)
        self.MainWindow.spinSpeed.valueChanged.connect(self.speed)

        self.MainWindow.sliderBarrera1.setValue(60)
        self.MainWindow.sliderBarrera2.setValue(160)

        self.timer_frames = QtCore.QTimer(self.MainWindow)
        self.timer_frames.timeout.connect(self.gmg)  # timer para refrescar la ventana
        self.timer_frames.start(self.speed_default)

        #Se le asigna un comportamiento a los botones de la interfaz
        self.MainWindow.buttonRestart.clicked.connect(self.restart)
        self.MainWindow.buttonPause.clicked.connect(self.startStop)
        self.MainWindow.buttonDebug.clicked.connect(self.debug)      #Este es el Show all windows.
        self.MainWindow.buttonCloseDebug.clicked.connect(self.closeWindows)

    def closeWindows(self):
        self.mostrarVentanas = False
        cv2.destroyAllWindows()

    def startStop(self):
        if self.timer_frames.isActive():
            self.timer_frames.stop()
        else:
            self.timer_frames.start(self.speed_actual)

    def restart(self):
        self.state = st.States.DENTRO
        self.contador = 1
        self.timer_frames.stop()
        self.cap = cv2.VideoCapture('video.wmv')
        self.timer_frames.start(self.speed_actual)

    def speed(self):
        # A la hora de cambiar el speed se para el timer y se vuelve a iniciar con el nuevo speed
        # Se multiplica por 0.1 para que la regulación de velocidad sea más precisa.
        # Por ejemplo, si el valor de self.MainWindow.spinSpeed.value() es 10, el speed será 2x.
        # En cambio, si ese valor es 4, el speed será 1.4x.
        self.timer_frames.stop()
        self.speed_actual = int(self.speed_default / (1 + self.MainWindow.spinSpeed.value() * 0.1))
        self.timer_frames.start(self.speed_actual)

    def debug(self):
        self.mostrarVentanas = True

    def change_barrier(self):
        b1 = self.tamY - self.MainWindow.sliderBarrera1.value()
        b2 = self.tamY - self.MainWindow.sliderBarrera2.value()
        if b1 > b2:
            self.MainWindow.spinBarrera1.setValue(
                int((self.tamY - self.MainWindow.sliderBarrera1.value()) / self.tamY * 100))
            self.MainWindow.spinBarrera2.setValue(
                int((self.tamY - self.MainWindow.sliderBarrera2.value()) / self.tamY * 100))

    def show(self):
        self.MainWindow.show()

    def pintarBarreras(self, img, lowBarrier, highBarrier):
        cv2.line(img, (0, lowBarrier), (self.tamX, lowBarrier), (255, 0, 0), 2)
        cv2.line(img, (0, highBarrier), (self.tamX, highBarrier), (0, 255, 0), 2)

    # Funciona como el Compute en la versión C++
    def gmg(self):
        ret, frame = self.cap.read()
        if ret:
            # Al principio del bucle, se coge el primer frame del video y se convierte a escala de grises
            if not self.primeraIsTaken:
                self.primeraIsTaken = True
                gray = cv2.cvtColor(frame.copy(), cv2.COLOR_BGR2GRAY)
                self.primeraImagen = cv2.resize(gray, (self.tamX, self.tamY))

            finalImg = cv2.resize(frame, (self.tamX, self.tamY))
            cY = imageProcess.getCentroideY(finalImg, self.primeraImagen, self.tamX, self.mostrarVentanas)

            lowBarrier = int(self.MainWindow.spinBarrera1.value() * self.tamY / 100)
            highBarrier = int(self.MainWindow.spinBarrera2.value() * self.tamY / 100)
            self.pintarBarreras(finalImg, lowBarrier, highBarrier)
            self.changeState(cY, lowBarrier, highBarrier)

            image = QtGui.QImage(finalImg, finalImg.shape[1], finalImg.shape[0], finalImg.shape[1] * 3,
                                 QtGui.QImage.Format_RGB888)
            pix = QtGui.QPixmap(image)
            self.MainWindow.video_source.setPixmap(pix)
        else:
            self.MainWindow.video_source.setText("The video has ended")
            self.closeWindows()
            self.timer_frames.stop()

    def changeState(self, cY, lowerBarrier, upperBarrier):
        if cY == -1:
            # Si no hay centroide, no se detecta nada en la habitación y, por tanto, no se hace nada
            return

        if self.state == st.States.FUERA:
            if upperBarrier < cY < lowerBarrier:
                self.state = st.States.ENTRANDO

        elif self.state == st.States.ENTRANDO:
            if cY < upperBarrier:
                # Si algo esta entrando y al final termina dentro, se suma 1 al contador
                self.state = st.States.DENTRO
                self.contador += 1
                self.MainWindow.counter.setText("counter: " + str(self.contador))
                print(self.contador)
            elif cY > lowerBarrier:
                self.state = st.States.FUERA

        elif self.state == st.States.DENTRO:
            if upperBarrier < cY < lowerBarrier:
                self.state = st.States.SALIENDO

        elif self.state == st.States.SALIENDO:
            if cY < upperBarrier:
                self.state = st.States.DENTRO
            elif cY > lowerBarrier:
                # Si algo esta saliendo y al final termina fuera, se resta 1 al contador
                self.state = st.States.FUERA
                self.contador -= 1
                self.MainWindow.counter.setText("counter: " + str(self.contador))
                print(self.contador)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    app.exec_()
