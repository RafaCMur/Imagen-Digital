class Detector:
    def __init__(self, limit1, limit2, limit3, limit4, direction):
        self.limitLX = limit1 # Lower X
        self.limitUX = limit2 # Upper X
        self.limitLY = limit3 # Lower Y
        self.limitUY = limit4  # Upper Y
        self.direction = direction
        self.state = 1

    def getLimitUX(self):
        return self.limitUX

    def getLimitUY(self):
        return self.limitUY

    def getLimitLX(self):
        return self.limitLX

    def getLimitLY(self):
        return self.limitLY

    def getState(self):
        return self.state

    def getDirection(self):
        return self.direction

    def updateState(self, state):
        self.state = state
        if state == 3:
            self.state = 1
