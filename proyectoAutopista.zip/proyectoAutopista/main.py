import cv2
import numpy as np

import Detector as d

class main:
    def __init__(self):
        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))
        self.fgbg = cv2.createBackgroundSubtractorMOG2(1)
        self.cap = cv2.VideoCapture('video2.mp4')
        self.listaDetectores = []
        self.sumIzq = 0
        self.sumDer = 0

    def cargarDetectores(self):

        self.listaDetectores.append(d.Detector(200, 270, 280, 285, 0))

        self.listaDetectores.append(d.Detector(270, 320, 280, 285, 0))

        self.listaDetectores.append(d.Detector(320, 390, 280, 285, 0))

        self.listaDetectores.append(d.Detector(470, 530, 300, 305, 1))

        self.listaDetectores.append(d.Detector(530, 610, 300, 305, 1))

        self.listaDetectores.append(d.Detector(610, 730, 300, 305, 1))

    def pintarDetectores(self, frame):
        for detector in self.listaDetectores:
            cv2.rectangle(frame, (detector.getLimitLX(), detector.getLimitLY()), (detector.getLimitUX(), detector.getLimitUY()), (0, 255, 0), 2)

    def contarVehiculos(self, cx, cy):
        for detector in self.listaDetectores:
            if detector.getDirection() == 0:
                if detector.getState() == 1:
                    if detector.getLimitLX() <= cx <= detector.getLimitUX() and detector.getLimitLY() <= cy <= detector.getLimitUY():
                        detector.updateState(2)
                elif detector.getState() == 2:
                    if detector.getLimitLX() <= cx <= detector.getLimitUX() and detector.getLimitLY()-15 < cy < detector.getLimitLY():
                        detector.updateState(3)
                        self.sumIzq += 1
                        print ("Vehiculos por la izquierda: ", self.sumIzq)
            elif detector.getDirection() == 1:
                if detector.getState() == 1:
                    if detector.getLimitLX() <= cx <= detector.getLimitUX() and detector.getLimitLY() <= cy <= detector.getLimitUY():
                        detector.updateState(2)
                elif detector.getState() == 2:
                    if detector.getLimitLX() <= cx <= detector.getLimitUX() and detector.getLimitLY() < cy < detector.getLimitUY()+15:
                        detector.updateState(3)
                        self.sumDer += 1
                        print ("Vehiculos por la derecha: ", self.sumDer)

    def run(self):

        while (1):
            ret, frame = self.cap.read()

            if not ret:
                break


            fgmask = self.fgbg.apply(frame)
            fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, self.kernel)

            kernel2 = np.ones((4, 4), np.uint8)
            dilated = cv2.dilate(fgmask, kernel2, iterations=1)

            contours, hierarchy = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            # Pintar los contornos
            for c in contours:
                if cv2.contourArea(c) < 900:
                    continue
                # Localizar centroide
                M = cv2.moments(c)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    cv2.circle(frame, (cx, cy), 7, (255, 255, 255), -1)
                    self.contarVehiculos(cx, cy)


            self.pintarDetectores(frame)

            cv2.imshow('Real video', frame);

            cv2.imshow('Foreground', dilated);

            k = cv2.waitKey(30) & 0xff
            if k == 27:
                break

        print("Total de vehiculos por la izquierda: ", self.sumIzq)
        print("Total de vehiculos por la derecha: ", self.sumDer)
        print("Total de vehiculos: ", self.sumIzq + self.sumDer)
        self.cap.release()
        cv2.destroyAllWindows()

if __name__ == '__main__':

    m = main()
    m.cargarDetectores()
    m.run()